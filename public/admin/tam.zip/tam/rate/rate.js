$(document).ready(function () {

    $('.input-3').rating({displayOnly: true, step: 0.5});


    $('#input-2').on('change', function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // e.preventDefault();
        var route = $('.hide').data('route');
        var rate = $('input[name="rate"]').val();
        var productId = $('#product-id').val();
        // alert(route);
        var userId = $('#user_id').val();
        console.log(userId);
        $.ajax({
            type: 'POST',
            url: route,
            dataType: 'JSON',
            data: {
                'product_id': productId,
                'rate' : rate,
                'user_id': userId,
            },
            success: function(data){
                if (data.success) {
                    console.log(data)
                }else alert("not");
            }});
    });
});
